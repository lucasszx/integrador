package apresentação;

import model.Aluno;
import persistencia.AlunoDAO;

public class TesteAluno {

	public static void main(String[] args) {

//		TESTE DO SALVAR		
		Aluno u = new Aluno();
		u.setNome("Lucas Nunes Ferreira");
		u.setMatricula("20221ss.inf_q0001");
		u.setSenha("123");

		AlunoDAO uDAO = new AlunoDAO();
		u = uDAO.salvar(u);
		System.out.println(u.toString());

	}

}
