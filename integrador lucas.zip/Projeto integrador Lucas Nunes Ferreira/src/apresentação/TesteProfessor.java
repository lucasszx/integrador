package apresentação;

import model.Professor;
import persistencia.ProfessorDAO;

public class TesteProfessor {

	public static void main(String[] args) {

//		TESTE DO SALVAR		
		Professor u = new Professor();
		u.setNome("Lucas Nunes Ferreira");
		u.setMatricula("20221ss.inf_q0001");
		u.setSenha("123");

		ProfessorDAO uDAO = new ProfessorDAO();
		u = uDAO.salvar(u);
		System.out.println(u.toString());

	}

}
