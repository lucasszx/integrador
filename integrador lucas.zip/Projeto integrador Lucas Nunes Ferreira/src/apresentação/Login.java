package apresentação;

import java.util.Scanner;

import persistencia.AlunoDAO;
import persistencia.MonitorDAO;
import persistencia.ProfessorDAO;

public class Login {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Bem-vindo! Faça seu Login!");
		System.out.println("Escolha uma opção:");
		System.out.println("1. Login como Aluno");
		System.out.println("2. Login como Professor");
		System.out.println("3. Login como Monitor");
		System.out.print("Digite o número da opção desejada: ");

		int opcao = scanner.nextInt();
		scanner.nextLine(); 

		switch (opcao) {
		case 1:
			loginAluno(scanner);
			break;
		case 2:
			loginProfessor(scanner);
			break;
		case 3:
			loginMonitor(scanner);
			break;
		default:
			System.out.println("Opção inválida.");
		}

		scanner.close();
	}

	private static void loginAluno(Scanner scanner) {
		System.out.print("Digite sua matrícula: ");
		String matricula = scanner.nextLine();

		System.out.print("Digite sua senha: ");
		String senha = scanner.nextLine();

		Exemplo: if (AlunoDAO.buscarPorId(matricula, senha)) {
			System.out.println("Login bem-sucedido como aluno.");
		} else {
			System.out.println("Credenciais inválidas.");
		}
	}

	private static void loginProfessor(Scanner scanner) {
		System.out.print("Digite sua matrícula: ");
		String matricula = scanner.nextLine();

		System.out.print("Digite sua senha: ");
		String senha = scanner.nextLine();
		if (ProfessorDAO.validarCredenciais(matricula, senha)) {
			System.out.println("Login bem-sucedido como professor.");
		} else {
			System.out.println("Credenciais inválidas.");
		}
	}

	private static void loginMonitor(Scanner scanner) {
		System.out.print("Digite sua matrícula: ");
		String matricula = scanner.nextLine();

		System.out.print("Digite sua senha: ");
		String senha = scanner.nextLine();

		Exemplo: if (MonitorDAO.validarCredenciais(matricula, senha)) {
			System.out.println("Login bem-sucedido como monitor.");
		} else {
			System.out.println("Credenciais inválidas.");
		}
	}
}
