package apresentação;

import model.Monitor;
import persistencia.MonitorDAO;

public class TesteMonitor {

	public static void main(String[] args) {

//		TESTE DO SALVAR		
		Monitor u = new Monitor();
		u.setNome("Lucas Nunes Ferreira");
		u.setMatricula("20221ss.inf_q0001");
		u.setSenha("123");

		MonitorDAO uDAO = new MonitorDAO();
		u = uDAO.salvar(u);
		System.out.println(u.toString());

	}

}
