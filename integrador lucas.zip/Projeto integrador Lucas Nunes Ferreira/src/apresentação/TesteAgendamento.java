package apresentação;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import model.Agendamento;
import model.Aluno;
import model.Disciplina;
import model.Monitor;
import persistencia.AgendamentoDAO;

public class TesteAgendamento {

	public static void main(String[] args) {

//		TESTE DO SALVAR		
		Agendamento u = new Agendamento();
		u.setHorarioInicio(LocalDateTime.of(LocalDate.now().getYear(), 01, 18, 10, 45));
		u.setHorarioFim(LocalDateTime.of(LocalDate.now().getYear(), 01, 18, 11, 30));
		u.setDescricaoFinal("Atendimento feito! Estudamos programação");

		AgendamentoDAO uDAO = new AgendamentoDAO();
		u = uDAO.salvar(u);
		System.out.println(u.toString());

	}

}

