package apresentação;

import java.util.Scanner;

import model.Aluno;
import model.Disciplina;
import model.Monitor;
import model.Professor;
import persistencia.AlunoDAO;
import persistencia.MonitorDAO;
import persistencia.ProfessorDAO;

public class Cadastro {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bem-vindo ao cadastro! Selecione seu tipo de Usuário");
        System.out.println("Escolha uma opção:");
        System.out.println("1. Cadastrar como Aluno");
        System.out.println("2. Cadastrar como Professor");
        System.out.println("3. Cadastrar como Monitor");
        System.out.print("Digite o número da opção desejada: ");

        int opcao = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha pendente

        switch (opcao) {
            case 1:
                cadastrarAluno(scanner);
                break;
            case 2:
                cadastrarProfessor(scanner);
                break;
            case 3:
                cadastrarMonitor(scanner);
                break;
            default:
                System.out.println("Opção inválida.");
        }

        scanner.close();
    }

    private static void cadastrarAluno(Scanner scanner) {
    	System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite sua matrícula: ");
        String matricula = scanner.nextLine();

        System.out.print("Digite sua senha: ");
        String senha = scanner.nextLine();
        Aluno aluno = new Aluno(0, nome, matricula, senha, null);
        AlunoDAO alunoDAO = new AlunoDAO();
        alunoDAO.salvar(aluno);
        
        System.out.println("Cadastro de aluno concluído.");
    }

    private static void cadastrarProfessor(Scanner scanner) {
        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite sua matrícula: ");
        String matricula = scanner.nextLine();

        System.out.print("Digite sua senha: ");
        String senha = scanner.nextLine();
        Professor professor = new Professor(0, nome, matricula, senha, null);
        ProfessorDAO professorDAO = new ProfessorDAO();
        professorDAO.salvar(professor);

        System.out.println("Cadastro de professor concluído.");
    }

    private static void cadastrarMonitor(Scanner scanner) {
        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();

        System.out.print("Digite sua matrícula: ");
        String matricula = scanner.nextLine();

        System.out.print("Digite sua senha: ");
        String senha = scanner.nextLine();

        System.out.print("Digite o ID da disciplina que irá monitorar: ");
        Disciplina idDisciplina = new Disciplina();
        long id = scanner.nextLong();
        idDisciplina.setIdDisciplina(id);
        scanner.nextLine(); // Consumir a quebra de linha pendente
        
        Monitor monitor = new Monitor(0, nome, matricula, senha, null, idDisciplina);
        MonitorDAO monitorDAO = new MonitorDAO();
        monitorDAO.salvar(monitor);
       
        // Aqui você pode criar uma instância da classe Monitor e fazer algo com ela
        // Exemplo: Monitor monitor = new Monitor(nome, matricula, senha, idDisciplina);
        //       MonitorService.cadastrarMonitor(monitor);

        System.out.println("Cadastro de monitor concluído.");
    }
}
